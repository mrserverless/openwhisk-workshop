function main(msg) {
    return { message: "Hello, " + msg.name + " from " + msg.place };
}